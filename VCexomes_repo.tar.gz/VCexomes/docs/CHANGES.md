# Changes with respect to the original scripts

This repository is a tidied snapshot of the scripts that produced the FISDM4
exome call set. The analysis itself is unchanged: the same tools, the same
parameters and the same reference data. What changed is the packaging, plus a
number of defects that had to be fixed for the scripts to run as written.

Everything in the last section is a behaviour change that needs confirming
against the run log before the repository is considered final.

## Script mapping

| Original | Now | Note |
|---|---|---|
| `step1_QCtrim_fof_v3.batch` | `scripts/step01_qc_trim.batch` | v3 taken as the base |
| `step1_QCtrim_fof.batch` | `deprecated/` | superseded by v3 |
| none | `scripts/step02_multiqc.batch` | reconstructed, see below |
| `step3_alignment.batch` | `scripts/step03_alignment.batch` | |
| `step4_runAddOrReplaceRG.batch` | `scripts/step04_add_readgroups.batch` | manifest lookup rewritten |
| `step5_mergeBAM.batch` | `scripts/step05_merge_bam.batch` | input pattern corrected |
| `step6_markDup.batch` | `scripts/step06_markdup.batch` | `.cmd` indirection removed |
| `step7_runRecal.batch` | `scripts/step07_bqsr.batch` | commented code restored |
| `step8_runGVariantCallingGATK.batch` | `scripts/step08_haplotypecaller.batch` | commented code restored |
| `step9_runVariantCallingGATK.batch` | `deprecated/` | duplicate of step 8 |
| `step10_runGenomicsDBImport.batch` | `deprecated/` | route not used in the final run |
| `step11_runGenotypeGVCFs_chr.batch` and `_chr_decoy.batch` | `scripts/step09_combine_gvcfs.batch` | unified through a shard list |
| `step11_runGenotypeGVCFs.batch` | `scripts/step10_genotype_gvcfs.batch` and `scripts/step11_vqsr.batch` | split, commented code restored |
| `step12_vep_annotation.sh` | `scripts/step12_vep_annotation.batch` | |
| `CollectHSMetrics.sh` | `qc/collect_hs_metrics.batch` | |
| `VCexomes_coverage_step2.py` | `qc/coverage_plots.py` | renamed, it is a QC utility rather than step 2 |
| `autoadapter.sh` | `src/autoadapter.sh` | kept as a utility, no step calls it |

## Homogenisation

* Every step is now a SLURM array job that sources the same configuration file
  and the same helper library (`src/common.sh`), and takes its input from a
  file-of-files list. The launcher `VCexomes.sh` submits the enabled steps and
  chains them with `--dependency=afterok`.
* Array sizes are computed from the number of lines of the corresponding list
  rather than hard coded in the `#SBATCH` header, and are throttled with the
  `max_concurrent` setting.
* All absolute paths (reference, GATK bundle, capture panel, VEP cache, Picard
  jar, Trim Galore) moved to `config/fisdm4.cfg`.
* Array indices are zero based everywhere. `CollectHSMetrics.sh` used a one
  based array, which is why it was submitted as `1-2198`.
* Sample names are derived with `basename` instead of `cut -d '/' -f 12` or
  `-f 14`, which depended on the depth of the directory tree.
* All scripts run under `set -euo pipefail`, log with timestamps and validate
  their inputs before doing any work. Comments and messages are in English.
* The write-to-`.cmd`-then-execute pattern of steps 4, 6 and 7 was replaced by
  direct calls plus the `_status` markers. In step 6 the `.cmd` file name was
  built with `$(date +"%Y-%m-%d_%H-%M")` evaluated separately on each line, so
  a run crossing a minute boundary wrote one file and executed another.

## Defects fixed

* `step1_QCtrim_fof.batch` referenced `${outtrim}/${}`, an empty expansion, and
  used `$outtrim` before assigning it. The check was also comparing against
  files in the postQC folder, which only ever holds FastQC reports, so it never
  matched. The resume check now looks for the trimmed FASTQ file.
* `step4` looped over the whole manifest for every array task and matched only
  the sample field, so a sample sequenced in several lanes had read groups
  overwritten once per manifest row, with the last row winning. The lookup is
  now an exact match on `sample_batch_flowcell_lane`, and a missing key is an
  error instead of a silent skip. Its guard also compared `$sample` against an
  output named after `$sample_id`.
* `step5` searched for `*.rgmod.sort.bam`, a suffix no step produced (step 4
  writes `.rgmod.bam`, already coordinate sorted). With no matches it fell
  through to a `cp` of the same non-existent pattern. It now searches for
  `*.rgmod.bam`.
* `step8` wrote `${sample}_raw.snps.indels.gvcf` but its resume check looked
  for `${sample}.raw.snps.indels.gvcf`, so it never skipped a finished sample.
* `step7_merge_vcf.sh` in the sibling VCamplicons repository has the same class
  of defect and is unrelated to this pipeline.
* Steps 5 and 6 used the undefined environment variable `$picard`. It is now
  the configuration entry `picard_jar`.
* `step11` mixed one gVCF list (`gvcf_more_20x_cov.fof`) with a second
  unused one (`gvcf_chr_2187.fof`). Only the coverage-filtered list is kept.

## Reactivated code

The commented-out blocks were restored as running code, exactly as written:

* Step 07: `BaseRecalibrator`, `ApplyBQSR`, second `BaseRecalibrator` and
  `AnalyzeCovariates`. Only `AnalyzeCovariates` was active in the original.
* Step 08: `HaplotypeCaller` in gVCF mode with `StandardAnnotation` and
  `AS_StandardAnnotation`.
* Steps 10 and 11: `GenotypeGVCFs`, the SNP and INDEL `VariantRecalibrator`
  passes, both `ApplyVQSR` calls and the `sed`/`Rscript` fix applied to the
  tranche plot scripts. Only the final `bcftools view` was active.

## Points to confirm

1. **Step 02 was reconstructed.** No MultiQC script was recovered. The one here
   is inferred from the workflow diagram and from the equivalent VCamplicons
   step, so its output paths are a proposal.
2. **gVCF extension.** Step 08 now writes `_raw.snps.indels.g.vcf.gz`. The two
   original scripts disagreed (`.gvcf` and `.g.vcf`, both uncompressed).
3. **Per-shard genotyping.** The original combined the gVCFs per chromosome but
   genotyped a single whole-cohort file. Here `GenotypeGVCFs` runs per shard and
   the shards are concatenated with `bcftools concat` at the start of step 11.
   The variant set is the same, the intermediate file names are not.
4. **dbSNP copy.** BQSR used `${gatk_bundle}/chr/dbsnp_146.hg38.vcf.gz` and VQSR
   used `${gatk_bundle}/dbsnp_146.hg38.vcf.gz`. Both are kept as separate
   configuration entries because it is not clear whether the difference was
   deliberate.
5. **`--RGCN`.** The read group centre field is filled with the Novogene project
   name, which is what the original did.
6. **Duplicate removal before or after sorting.** The diagram shows
   MarkDuplicates followed by a SAMtools sort; the script sorts with Picard
   SortSam first and then removes duplicates. The script order was kept.
7. **`coverage_plots.py`.** The `--filter` argument accepted `pool12`, `pool96`
   and `center`, but the metadata columns read from the pool file are `sample`,
   `gatk_processed_mean_coverage`, `gatk_processed_median_coverage` and
   `library`, so any of those values raised a `KeyError`. The argument is now
   `--group-by`, the column names are configurable with `--db-columns`, and an
   unknown column produces a message listing the available ones.
8. **`picard_jar` and `raw_fastq_dir`** are marked `TODO` in the configuration
   file. Neither was recorded in the original scripts.

## Not included

The workflow diagram shows three QC branches for which no script was recovered:
sample identity QC (ancestry, relatedness, sex inference), variant QC and the
hard filters applied after annotation. The sample counts in the diagram
(2,198 samples sequenced, 2,187 recalibrated, 2,092 after filtering) come from
those steps, so the repository cannot reproduce the final cohort on its own.
