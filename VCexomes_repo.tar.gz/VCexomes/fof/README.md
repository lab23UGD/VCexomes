# File-of-files lists

Every array step reads one entry per array task from a plain text list, so the
array size never has to be hard coded. The lists are not tracked by git because
they contain absolute paths of the working tree; rebuild them with:

```bash
bash src/make_fof.sh config/fisdm4.cfg all
```

| List | Built by | Used by | Entries in the FISDM4 run |
|---|---|---|---|
| **raw_fastq.fof** | manual, from the delivery folders | steps 01 and 03 | 17,494 R1 files |
| **samples.fof** | `make_fof.sh samples` | step 05 | 2,198 samples |
| **bam_raw.fof** | `make_fof.sh bam_raw` | step 04 | one per sequencing run |
| **bam_merged.fof** | `make_fof.sh bam_merged` | step 06 | 2,198 |
| **bam_rgmod_merged_sort_rmdp.fof** | `make_fof.sh bam_rmdp` | step 07 | 2,198 |
| **bam_rgmod_merged_sort_rmdp_BQSR.fof** | `make_fof.sh bam_bqsr` | step 08 and the HS metrics QC | 2,187 |
| **gvcf_more_20x_cov.fof** | `make_fof.sh gvcf`, then filtered by coverage | step 09 | samples above 20x |

The shard list (`combine_shards.txt`) and the decoy contig list
(`chr_decoy_list.txt`) live in `required_files` and are not regenerated: the
first holds the 24 primary contigs plus the literal keyword `decoy`, the second
holds the decoy contigs that are combined in a single job.
