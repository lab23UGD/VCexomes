#!/bin/bash

# Usage: autodetect.sh file.fq.gz

# ADAPTER AUTO-DETECTION

outdir=$2

# run if file exists and is a regular file
if [ ! -f ${outdir}/autodetect-statistics.txt ]; then
        echo -e "\n\nAUTO-DETECTING ADAPTER TYPE\n===========================" >> ${outdir}/autodetect-statistics.txt
        echo -e "Attempting to auto-detect adapter type from the first 1 million sequences of the first file (>> $1 <<)\n" >> ${outdir}/autodetect-statistics.txt
else
	rm ${outdir}/autodetect-statistics.txt
	echo -e "\n\nAUTO-DETECTING ADAPTER TYPE\n===========================" >> ${outdir}/autodetect-statistics.txt
	echo -e "Attempting to auto-detect adapter type from the first 1 million sequences of the first file (>> $1 <<)\n" >> ${outdir}/autodetect-statistics.txt
fi

if [ $# -eq 0 ]; then
  echo "Error: no input file specified"
  exit 1
fi

input_file=$1

if [ ! -f "$input_file" ]; then
  echo "Error: input file not found or is not a regular file"
  exit 1
fi

if [ ! -r "$input_file" ]; then
  echo "Error: input file is not readable"
  exit 1
fi

# Check if the input file is compressed and open accordingly
if [[ $input_file == *.gz ]]
then
#evaluate first 50k lines
zcat $input_file | head -100000 | awk 'NR%4==2' > ${outdir}/temp.txt
else
head -100000 $input_file | awk 'NR%4==2' > ${outdir}/temp.txt
fi

declare -A adapters

adapters['Illumina']='AGATCGGAAGAGC'
adapters['Nextera']='CTGTCTCTTATA'
adapters['smallRNA']='TGGAATTCTCGG'

#Count the number of occurrences of each adapter in the input file
for adapter in ${!adapters[@]}
do
count=$(grep -o ${adapters[$adapter]} ${outdir}/temp.txt | wc -l)
adapters[$adapter]=$count
done

#Find the adapter with the most occurrences and output a report
highest_adapter="Illumina"
highest_count=0

echo -e "adapter\tcounts\tadapter_counts\treads\tpercent" >> ${outdir}/autodetect-statistics.txt
for adapter in ${!adapters[@]}
do
count=${adapters[$adapter]}
#echo -e "$adapter\t$count\t${adapters[$adapter]}\t100000\t$(echo "scale=2; $count/100" | bc)%"
echo -e "$adapter\t$count\t100000\t$(echo "scale=2; $count/100" | bc)%" >> ${outdir}/autodetect-statistics.txt
if [[ $count -gt $highest_count ]]
then
highest_count=$count
highest_adapter=$adapter
fi
done

#Set the adapter name and sequence based on the most frequent adapter
if [[ $highest_adapter == "Illumina" ]]
then
adapter_name='Illumina TruSeq, Sanger iPCR; auto-detected'
adapter_seq='AGATCGGAAGAGC'
elif [[ $highest_adapter == "Nextera" ]]
then
adapter_name='Nextera Transposase sequence; auto-detected'
adapter_seq='CTGTCTCTTATA'
elif [[ $highest_adapter == "smallRNA" ]]
then
adapter_name='Illumina small RNA adapter; auto-detected'
adapter_seq='TGGAATTCTCGG'
fi

echo -e "\nMost frequent adapter: $adapter_name ($highest_count occurrences)\n" >> ${outdir}/autodetect-statistics.txt

#Clean up temp file
#rm ${outdir}/temp.txt


# Result used as argument to QCtrim.sh
echo  -e "$highest_adapter"

